<?php
/*
Plugin Name:  xfil Woocommerce
Plugin URI:   https://www.hypersrv.com
Description:  Links products to programs on the network.
Version:      1
Author:       hypersrv
Author URI:   https://www.hypersrv.com
License:      NON FREE
License URI:  
Text Domain:  
Domain Path:  
*/
defined( 'ABSPATH' ) or die( 'No!' );

class XfilPlugin {
    
    public function __construct()
    {
        add_action('woocommerce_thankyou', array($this, 'xfilCheckout'));
        add_action('wp_footer', array($this, 'xfilJs'), 100);
        add_filter('woocommerce_product_data_tabs', array($this, 'custom_product_tabs'));
        add_filter('woocommerce_product_data_panels', array($this, 'giftcard_options_product_tab_content')); // WC 2.6 and up
    }

    public function xfilCheckout($order_id)
    {
        $order = wc_get_order( $order_id );
        $product_ids = array();
        $xfil_ids = array();
        $total = 0;
        foreach( $order->get_items() as $item_id => $item_product ){
            array_push($product_ids, $item_product->get_product_id());
            $product = $item_product->get_product();
            if ($product->get_attribute('xfil')) {
                array_push($xfil_ids, $product->get_attribute('xfil'));
                $total += (float)$item_product->get_total();
            }
        }
        $backend = getenv('XFIL_BACKEND') ? getenv('XFIL_BACKEND') :'https://affiliates.sellfastinternational.com';
        echo "<script>var XFIL = {'xfil_ids': ".json_encode($xfil_ids).", 'order_id' : $order_id, 'order_total': $total, 'product_ids' : ".json_encode($product_ids).", 'backend' : '".$backend."/api/s'}</script>";

    }

    public function xfilJs() 
    {

        echo "<!-- xfil start -->";
        $backend = getenv('XFIL_BACKEND') ? getenv('XFIL_BACKEND') :'https://affiliates.sellfastinternational.com';
        echo '<script src="'.$backend.'/js/1.js" type="text/javascript" defer="defer"></script>';
        echo "<!-- xfil end -->";
    }

    /**
     * Add a custom product tab.
     */
    public function custom_product_tabs( $tabs) {
        $tabs['xfil'] = array(
            'label' => __('Affiliate', 'woocommerce'),
            'target' => 'affiliate_options',
            'class' => array( 'show_if_simple', 'show_if_variable'  ),
            'priority' => 60
        );
        return $tabs;
    }

    /**
     * Contents of the gift card options product tab.
     */
    public function giftcard_options_product_tab_content() 
    {
        global $post;
        ?>
        <div id='affiliate_options' class='panel woocommerce_options_panel'>
        <div class='options_group'>
        <?php
        woocommerce_wp_checkbox( array(
				'id' 		=> '_list_in_xfil',
				'label' 	=> __( 'List in affiliate system', 'woocommerce' ),
			) );
        ?>
        </div>
        </div>
        <?php
    }


}

$xfil = new XfilPlugin();